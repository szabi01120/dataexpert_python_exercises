baseDir = 'N:\\Python\\Personal_Folders\\HSZ\\python_csv_project'
dataDirName = 'data'